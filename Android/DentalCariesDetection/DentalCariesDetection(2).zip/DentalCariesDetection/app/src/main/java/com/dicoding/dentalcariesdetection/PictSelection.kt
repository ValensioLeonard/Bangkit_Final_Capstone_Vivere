package com.dicoding.dentalcariesdetection

import android.app.Activity
import android.content.ContentValues.TAG
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.*
import retrofit2.*
import com.github.dhaval2404.imagepicker.ImagePicker
import kotlinx.android.synthetic.main.activity_pict_selection.*

class PictSelection : AppCompatActivity() {
    private lateinit var imageInput : ImageView
    private var imageUri : Uri? = null
    private lateinit var imageBitmap : Bitmap

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pict_selection)

        imageInput = findViewById(R.id.img_input)
        imageUri = intent.getParcelableExtra("imageUri")
        imageInput.setImageURI(imageUri)
        imageBitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, imageUri)

        btnRetake.setOnClickListener {
            startImagePicker()
        }

        btnContinueResult.setOnClickListener{
            postImageToApi(imageBitmap)
        }
    }

    private fun postImageToApi(imageBitmap: Bitmap) {
        val client = ApiConfig.getApiService().postImage(imageBitmap)
        client.enqueue(object : Callback<PostImageResponse> {
            override fun onResponse(call: Call<PostImageResponse>, response: Response<PostImageResponse>){
                if (response.isSuccessful)
                {
                    if (response.message() == "Gigi Sehat"){
                        goodResultIntent()
                    }else if (response.message() == "Gigi Karies"){
                        badResultIntent()
                    }else{
                        Log.e(TAG, "onFailure: ${response.message()}")
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<PostImageResponse>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
    }

    private fun badResultIntent() {
        val badResultIntent = Intent(this, BadResultActivity::class.java)
        startActivity(badResultIntent)
    }

    private fun goodResultIntent() {
        val goodResultIntent = Intent(this, GoodResultActivity::class.java)
        startActivity(goodResultIntent)
    }

    private fun startImagePicker() {
        ImagePicker.with(this)
            .crop()
            .compress(1024)
            .start()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK){
            val uri : Uri = data?.data!!
            imageUri = uri
            imageInput.setImageURI(imageUri)
            imageBitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, imageUri)
        } else if (resultCode == ImagePicker.RESULT_ERROR) {
            Toast.makeText(this, ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Task Cancelled", Toast.LENGTH_SHORT).show()
        }
    }
}