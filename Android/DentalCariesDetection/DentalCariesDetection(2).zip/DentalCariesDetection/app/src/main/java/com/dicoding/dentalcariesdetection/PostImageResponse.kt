package com.dicoding.dentalcariesdetection

import com.google.gson.annotations.SerializedName

data class PostImageResponse(
    @field:SerializedName("message")
    val message : String
)