package com.dicoding.dentalcariesdetection

import android.graphics.Bitmap
import okhttp3.*
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @Multipart
    @POST("predict")
    fun postImage(
        @Part ("id") id: Bitmap,
        @Part file: MultipartBody.Part
    ): Call<PostImageResponse>
}